<?php 
include 'classes/my_website_functions.php';
auth_check();
include 'header.php';
?>



<?php 
    include 'footer.php';
?>
  