<?php 
include 'classes/my_website_functions.php';
auth_check();
?>
<?php
    $servername = "localhost";
    $username = "freewebi_new";
    $password = "hdsjd%QS232$";
    $dbname = "freewebi_new";
    $con=mysqli_connect($servername,$username,$password,$dbname);$con=mysqli_connect($servername,$username,$password,$dbname);
    $hiddenid=$_POST['hiddenid'];
			$content=$_POST['offer_content'];
			$amount=$_POST['usd_amount'];
			$amount=$_POST['usd_amount'];
			$sql="UPDATE offers SET offer_content='$content',usd_amount='$amount' WHERE id='$hiddenid' ";
			$result=mysqli_query($con,$sql);
if($result==true)
			{
				header("location:offers.php");
			}
			else
			{
				echo"something went wrong";
			}

?>
