<?php 
include 'classes/my_website_functions.php';
auth_check();
?>


<?php


    $servername = "localhost";
    $username = "freewebi_new";
    $password = "hdsjd%QS232$";
    $dbname = "freewebi_new";
    
	
	$con=mysqli_connect($servername,$username,$password,$dbname);

	// header("location:form.php");
			

			$qar=$_POST['QAR'];
			$aed=$_POST['AED'];
			$bhd=$_POST['BHD'];
			$usd=$_POST['USD'];
			$omr=$_POST['OMR'];
			$uae=$_POST['UAE'];
			$lbp=$_POST['LBP'];
			$egp=$_POST['EGP'];
			$sar=$_POST['SAR'];
			

			$sql="UPDATE money_conversion SET QAR='$qar',AED='$aed',BHD='$bhd',USD='$usd',OMR='$omr',UAE='$uae',LBP='$lbp',SAR='$sar',EGP='$egp' WHERE 1 ";
			
			
			$result=mysqli_query($con,$sql);


			if($result==true)
			{
				echo "Your data inserted successfully ! Enjoy :-)"; echo"<br/>";
				echo "<a href='admin.php'>click to back </a>";
			}
			else
			{
				echo"something went wrong";
			}

?>