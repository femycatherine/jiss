<?php
error_reporting(E_ALL & ~ E_NOTICE & ~ E_WARNING);
session_start();
require_once('PHPMailer_5.2.0/class.phpmailer.php');

function config()
{

    $servername = "localhost";
    $username = "freewebi_new";
    $password = "hdsjd%QS232$";
    $dbname = "freewebi_new";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

function login_check()
{
    $conn = config();
    $username = $_POST['username'];
    $password = $_POST['password'];
    $sql = "select * from users where username='$username'";

    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $db_password = $row['password'];

    if ($db_password == md5($password)) {
        
        $_SESSION['userid'] = $row['id'];
        $_SESSION['username'] = $username;
        $_SESSION['full_name'] = $row['full_name'];
        $_SESSION['email'] = $row['email'];

        
        header('Location: admin.php');
    }else {
        return 'Invalid, locked or Inactive credentails!';
    }
}

function auth_check()
{
    if (! isset($_SESSION['userid'])) {
        header('Location: login.php');
        exit();
    }
}

function logout()
{
    session_unset();
    header('Location: login.php');
    exit();
}

function get_offers()
{
    $conn = config();
    auth_check();
    $sql = "SELECT * FROM offers";
    $conn->query("SET NAMES UTF8");
    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        $result->free();
    }
    
    return $data;
}

function get_users()
{
    $conn = config();
    auth_check();
    $sql = "select * from users";
    
    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        $result->free();
    }

    return $data;
}

function delete_user() {
    $conn = config();
    auth_check();
    
    $id = $_REQUEST['id'];
    $sql = "delete from users WHERE id='$id'";
    
    $conn->query($sql);
}

function add_user() {
    $conn = config();
    auth_check();
    
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $name = $_POST['name'];
    $email = $_POST['email'];
    
   
    $sql = "INSERT INTO users ( username, full_name, email, password )  VALUES ('$username','$name','$email', '$password')";
    $result = $conn->query($sql);
    $last_id = $conn->insert_id;
    $roles = $_POST['roles'];

    foreach($roles as $key=>$value) {
        $sql = "INSERT INTO user_roles (user_id , role_id)  VALUES ('$last_id',$value)";
        $result = $conn->query($sql);
    }
}

function sendmail($body='', $subject = '', $to = '') {
    
    
    //include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded
    
    $mail             = new PHPMailer();
    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->Host       = ""; // SMTP server
    $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    // 1 = errors and messages
    // 2 = messages only
    $mail->SMTPSecure = 'optional';
    
    $mail->SMTPAuth = true;// enable SMTP authentication
    $mail->Host       = ""; // sets the SMTP server
    $mail->Port       = 587;                    // set the SMTP port for the GMAIL server
    $mail->Username   = "3a22328aec96b7ad054c170a01a29304"; // SMTP account username
    $mail->Password   = "1dcdd4a0b2d0d84ac7cae47141b841e6";        // SMTP account password
    
    
    $mail->SetFrom('jiss123@gmail.com', 'My Website');
    $mail->AddReplyTo("jiss123@gmail.com","noreply");
    
    $mail->Subject    = $subject;
    
    
    $arrContextOptions=array(
        "ssl"=>array(
            "verify_peer"=>false,
            "verify_peer_name"=>false,
        ),
    );
    
    
    $mail->MsgHTML($body);
    
    $mail_array =  explode(";", $to);
    
    for($i=0; $i<count($mail_array); $i++) {
        $mail->AddAddress($mail_array[$i], "");
    }
    
    if(!$mail->Send()) {
    } else {
    }
    
}
        

?>