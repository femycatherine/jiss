<?php 
    $servername = "localhost";
    $username = "freewebi_new";
    $password = "hdsjd%QS232$";
    $dbname = "freewebi_new";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    	$sql="select *from money_conversion ";
    		
    	$result=mysqli_query($conn,$sql);
    	
    	$fetch=mysqli_fetch_array($result);
    
    
    
    $lang_id = $_REQUEST['lang'];
    
    if($lang_id=='en') {
        $denote = '$&nbsp';
        $convert = $fetch['USD'];
        $new_content = $denote.(147*$fetch['USD']);
        $text_total =  "المجموع";
        
    }
    else if ($lang_id=='ba')
    {
        $lang_id = 'ba';
        $denote = 'BD&nbsp;';
        $convert = $fetch['BHD'];
        $new_content = $denote.(147*$fetch['BHD']);
        $text_total = "المجموع";
    }
    else if ($lang_id=='eg')
    {
        $lang_id = 'eg';
        $denote = 'EGP&nbsp;';
        $convert = $fetch['EGP'];
        $new_content = $denote.(147*$fetch['EGP']);
        $text_total = "المجموع";
    }
    else if ($lang_id=='ar')
    {
        $lang_id = 'ar';
        $denote = 'SAR&nbsp;';
        $convert = $fetch['SAR'];;
        $new_content = $denote.(147*$fetch['SAR']);
        $text_total = "المجموع";
    }
     else if ($lang_id=='le')
    {
        $lang_id = 'le';
        $denote = 'LBP&nbsp;';
        $convert = $fetch['LBP'];
        $new_content = $denote.(147*$fetch['LBP']);
        $text_total = "المجموع";
    }
     else if ($lang_id=='om')
    {
        $lang_id = 'om';
        $denote = 'OMR&nbsp;';
        $convert = $fetch['OMR'];
        $new_content = $denote.(147*$fetch['OMR']);
        $text_total = "المجموع";
    }
    else if ($lang_id=='qa')
    {
        $lang_id = 'qa';
        $denote = 'QAR&nbsp;';
        $convert = $fetch['QAR'];
        $new_content = $denote.(147*$fetch['QAR']);
        $text_total = "المجموع";
    }
    else if ($lang_id=='uae')
    {
        $lang_id = 'uae';
        $denote = 'UAE&nbsp;';
        $convert = $fetch['UAE'];
        $new_content = $denote.(147*$fetch['UAE']);
        $text_total = "المجموع";
    }


    else {
        
        $lang_id = 'ku';
        $denote = 'KWD&nbsp;';
        $convert = $fetch['KWD'];
        $new_content = $denote.(147*$fetch['KWD']);
        $text_total = "المجموع";
        
        
       
    }
    
    $sql = "SELECT * FROM offers where lang_id='ar'";
    $conn->query("SET NAMES UTF8");
    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        $result->free();
    }
    
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>freewebinar</title>
      <link rel="shortcut icon" href="assets/images/fav.png">
      <link href="assets/css/style.css" type="text/css" rel="stylesheet"/>
      <link href="assets/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      
      
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css" />
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="assets/css/animate.css" />
	<!-- CSS end here -->
	<!-- Google fonts start here -->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Roboto:300' rel='stylesheet' type='text/css'>
  
  
	<script type="text/javascript">
		function lang_selected(value) {
			window.location.href='/offers/index.php?lang='+value;
		}
	</script>
  
   </head>
   <body>


	<div class="container-fluid">
		<div class="row top-bg">
			<div class="col-md-6 col-12 logo-lf">
		    <img src="assets/images/logo.png" alt=""/> 
		    </div>
			<div class="col-md-6 col-12 selt">
			
				<select class="wcpbc-country-switcher country-switcher" onChange="lang_selected(this.value)">
						<option value="ba"  <?php if($lang_id=='ba')  { echo "selected"; } ?>>Bahrain</option>
						<option value="eg"  <?php if($lang_id=='eg')  { echo "selected"; } ?>>Egypt</option>
						<option value="ku"  <?php if($lang_id=='ku')  { echo "selected"; } ?>>Kuwait</option>
						<option value="le"  <?php if($lang_id=='le')  { echo "selected"; } ?>>Lebanon</option>
						<option value="om"  <?php if($lang_id=='om')  { echo "selected"; } ?>>Oman</option>
						<option value="qa"  <?php if($lang_id=='qa')  { echo "selected"; } ?>>Qatar</option>
						<option value="ar"  <?php if($lang_id=='ar')  { echo "selected"; } ?>>Saudi Arabia</option>
						<option value="uae" <?php if($lang_id=='uae') { echo "selected"; } ?>>United Arab Emirates</option>
						<option value="en"  <?php if($lang_id=='en')  { echo "selected"; } ?>>Others</option>
				</select>
				
				
			</div>
		</div>
	</div>

	<section class="main-wrapper">

		<section class="count-down-wrapper fade-down">
			<ul class="row count-down">                       
				<li>   
					<input class="knob days" data-readonly=true data-min="0" data-max="365" data-width="260" data-height="260" data-thickness="0.07" data-fgcolor="#34aadc" data-bgColor="#e1e2e6" data-angleOffset="180">
					<span id="days-title">days</span>
				</li    
				><li> 
					<input class="knob hour" data-readonly=true data-min="0" data-max="24" data-width="260" data-height="260" data-thickness="0.07" data-fgcolor="#4cd964" data-bgColor="#e1e2e6" data-angleOffset="180">
					<span id="hours-title">hours</span>
				</li    
				><li> 
					<input class="knob minute" data-readonly=true data-min="0" data-max="60" data-width="260" data-height="260" data-thickness="0.07" data-fgcolor="#ff9500" data-bgColor="#e1e2e6" data-angleOffset="180">
					<span id="mins-title">minutes</span>
				</li    
				><li> 
					<input class="knob second" data-readonly=true data-min="0" data-max="60" data-width="260" data-height="260" data-thickness="0.07" data-fgcolor="#ff3b30" data-bgColor="#e1e2e6" data-angleOffset="180">
					<span id="secs-title">seconds</span>
				</li>                
			</ul>              
		</section>

	</section>
	

<div class="container-fluid banner" style="background: url(assets/images/banner.jpg) no-repeat center top; background-size:cover;">

	<div class="row">
		<div class="col-md-4 col-xs-6 cta">
			<h1>تعلم آلية السماح والتسليم </h1>
			<h1>وعيش بحرية </h1>
			
			
			<div class="buttn"><a href="#">
				<h2>احصل على العرض </h2>
				<h2><del>$2518</del> – 317$</h2></a>
			</div>
			
		</div>

		
	</div>

</div>

<div class="container-fluid y-vid">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-12">
				<iframe width="100%" height="450" src="https://www.youtube.com/embed/bZ73ytI-vBo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</div>
	</div>
</div>

<div class="container-fluid sert">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-12">
		    <img src="assets/images/sert-14.png" alt=""/> 
		    <p>في حال لم تغير الدورة حياتك يمكنك استرجاع المبلغ المدفوع خلال 14 يوم من تاريخ اشتراكك عن طريق التواصل مع فريق العمل  </p>
		    </div>
		</div>
	</div>
</div>
     
     
     
     
<div class="container-fluid oft">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-12">
			<h1>هذا العرض خاص بك</h1>
			
<table style="width:65%; margin: 0 auto;" dir="rtl" lang="ar">
    
<?php 
$total = 0;

foreach($data as $val) {
    
    echo "<tr>";
        echo "<td>".$val['offer_content']."</td>";
        echo "<td>".$denote.($val['usd_amount']*$convert)."</td>";
    echo "</tr>";
    
    $total = $total + $val['usd_amount']*$convert;
    
}
    
?>
   

  <tr style="color: #FD0004; border-top: 2px solid #CFCFCF;">
    
    <td><?php echo $text_total;?></td>
    <td><?php echo $denote.$total;?></td>

  </tr>
</table>
		<h2>! لليوم فقط<br>
<?php echo $new_content; ?>
</h2>		
		
		
<div class="ofbt">
	<a href="#">احصل عالعرض</a>
</div>
		
			</div>
		</div>
	</div>
</div> 
     
     
<div class="container-fluid footer">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-12">
				<h6>All rights reserved by imfreenow</h6>
			</div>
		</div>
	</div>
</div>
     
     
     
      <script src="assets/js/jquery.3.2.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/script.js"></script> 
      
      	<script src="assets/js/jquery.validate.min.js"></script>
		<script src="assets/js/modernizr.js"></script> 
		<script type="text/javascript" src="assets/js/appear.js"></script> 
		<script type="text/javascript">
			$(window).load(function() {
				$('#status').fadeOut();
				$('#preloader').delay(350).fadeOut('slow');
				$('body').delay(350).css({'overflow':'visible'});
			})
		</script> 
		<script src="assets/js/jquery.knob.js"></script>
		<script src="assets/js/jquery.ccountdown.js"></script>
		<script src="assets/js/init.js"></script>
		<script src="assets/js/general.js"></script>



   </body>
</html>